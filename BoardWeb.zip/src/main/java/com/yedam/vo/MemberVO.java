package com.yedam.vo;

import lombok.Data;

@Data
public class MemberVO {
	private String memberId;
	private String memberName;
	private String password;
	private String responsibility;
}